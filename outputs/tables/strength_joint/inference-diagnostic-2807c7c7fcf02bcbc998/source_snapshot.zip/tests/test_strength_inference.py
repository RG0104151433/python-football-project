import copy
import numpy as np
import pytest
from scipy.special import ndtr
from src.strength_inference.worlds import complete_wdl, before_day
from src.strength_inference.targets import soft_probit_projection, probability_and_gradient
from src.strength_inference.methods import bartlett_weights, multiplier_draws, summarize_draws


def test_draw_completion_preserves_home_and_nonhome_odds():
    q = np.array([[.3,.2,.5],[.1,.4,.5]])
    p = complete_wdl([.7,.2],q,2)
    assert np.allclose(p.sum(axis=1),1)
    assert np.allclose(p[:,0],[.7,.2])
    assert np.allclose(p[:,1]/p[:,2],2*q[:,1]/q[:,2])


def test_completion_rejects_invalid_inputs():
    with pytest.raises(ValueError): complete_wdl([1.],[[.3,.2,.5]])
    with pytest.raises(ValueError): complete_wdl([.5],[[.3,.2,.5]],0)


def test_soft_projection_recovers_known_coefficients_without_real_fit():
    x = np.column_stack((np.ones(90), np.tile([-1,0,1],30)))
    beta = np.array([.1,-.3]); result=soft_probit_projection(x,ndtr(x@beta))
    assert np.max(abs(np.array(result['theta'])-beta))<1e-7
    assert not result['truth_precision_admitted']


def test_calendar_distance_is_not_active_date_distance():
    calendar=np.zeros((10,2)); calendar[0]=[1,2]; calendar[9]=[-1,3]
    draws=multiplier_draws(calendar,40000,3,71001)
    expected=np.array([[2,-1],[-1,13.]])
    assert np.max(abs(np.cov(draws,rowvar=False)-expected))<.22


def test_paired_models_share_weights_and_cross_term():
    rng=np.random.default_rng(71002); w=bartlett_weights(rng,30000,1,1)[:,0]
    # Same influence in M0/M3 cancels exactly; independent perturbations would not.
    assert np.max(abs(2*w-2*w))==0
    assert np.var(2*w-3*w)> .9


def test_multiplier_replay_is_deterministic():
    calendar=np.arange(60).reshape(20,3)/100
    assert np.array_equal(multiplier_draws(calendar,80,5,42),multiplier_draws(calendar,80,5,42))


def test_small_draws_do_not_produce_confidence_claim():
    assert summarize_draws(np.ones((2,4)))['status']=='INSUFFICIENT_DRAWS'
