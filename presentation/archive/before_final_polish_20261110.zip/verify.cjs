// Current presentation verification entry.
require('./verify_refinement.cjs');
