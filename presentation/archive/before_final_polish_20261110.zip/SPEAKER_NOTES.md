# Current 14-screen speaking guide — 10 November revision

1. Open the sealed envelope: a forecast made before kick-off can be inspected after the match.
2. Select the three rings; highlight a segment. Samples overlap across rings, not within them.
3. Add the match types. Compare the raw gap with the composition-adjusted gap; open the Q4 modal if needed.
4. Hover a continent. Show subgroup rates, then opponent settings. State the three project-specific geographic overrides.
5. Reveal opponent, venue, importance and schedule cards. Club imagery is an analogy, not a national-team model input.
6. Pick Brazil and China or South Africa; replay annual strength. Values are latent estimates, not ranks or goals.
7. Play the fixed-axis historical chart. Compare the compact points; scores fluctuate, and these are not uncertainty intervals.
8. Raise the six true 3D bars. Read exact loss and both memory axes. The display baseline is explained on the page.
9. Switch auxiliary three-way probabilities and main-model uncertainty glyphs. Different branches, different targets.
10. Keep the original result-import protocol. Pending matches are not counted; do not invent scores.
11. Reveal the eight research stages in order.
12. Archify repository map: evidence, execution, explanation/delivery. Point to actual folders.
13. State the three findings with their scope restrictions.
14. Thank the audience and invite questions / repository exploration.

Rehearse timing on the actual projector. This outline is not proof of a completed timed rehearsal. No actual fixture outcomes have been imported.
